const getAllTickets = async (req, res) => {};
const replyUser = async (req, res) => {};
const closeTicket = async (req, res) => {};

module.exports = { getAllTickets, replyUser, closeTicket };

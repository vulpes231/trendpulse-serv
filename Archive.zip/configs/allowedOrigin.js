const allowedOrigins = [
  "https://trendpulse.netlify.app",
  "http://localhost:5173",
  "https://admin.trendpulse.markets",
  "https://trendpulse.markets",
];

module.exports = { allowedOrigins };
